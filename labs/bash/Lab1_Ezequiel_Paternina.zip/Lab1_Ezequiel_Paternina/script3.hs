#!/bin/bash

extension=$1
directorio=$2

for archivo in "$directorio"/*."$extension"; do
	if [ -e "$archivo" ]; then
		echo "Archivo: $archivo"
	fi
done

