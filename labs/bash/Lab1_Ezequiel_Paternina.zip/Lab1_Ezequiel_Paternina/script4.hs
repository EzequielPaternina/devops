#!/bin/bash


if curl google.com > /dev/null 2>&1; then
	echo "Se encuentra conectado a internet"
else
	echo "No esta conectado a internet"
fi

