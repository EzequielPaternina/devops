#!/bin/bash

menu() {
echo "Menu:"
echo "1. Script1 - Numero par o impar"
echo "2. Script2 - Tamano de directorio y archivos que contiene"
echo "3. Script3 - Ver archivos en un directorio con una extension definida"
echo "4. Script4 - Hay conexion a internet?"
echo "5. Salir"
echo "Digite un numero del 1 al 5"
}

ejecutar_script1() {
echo "Digite un numero entero"
read n
./script1.hs $n
}

ejecutar_script2() {
echo "Escriba un directorio"
read dir
./script2.hs $dir
}

ejecutar_script3() {
echo "Escriba una extension sin el punto ej (txt,csv)"
read ext
echo "Escriba un directorio"
read dir
./script3.hs $ext $dir
}

ejecutar_script4() {
./script4.hs
}

while true; do
	menu
	read numero

	case $numero in
		1) ejecutar_script1 ;;
		2) ejecutar_script2 ;;
		3) ejecutar_script3 ;;
		4) ejecutar_script4 ;;
		5) exit 0 ;;
	esac
done
