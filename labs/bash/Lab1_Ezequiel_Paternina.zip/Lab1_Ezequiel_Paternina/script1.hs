#!/bin/bash

n=$1
if  [[ $((n % 2)) -eq 0 ]]; then
echo "El numero" $n  "es par"
else
echo "El numero" $n "es impar"
fi





