#!/bin/bash

directorio=$1


echo "El directorio tiene archivos usa el siguiente espacio del disc:\n"

du $directorio

echo "Los contenidos del" $directorio "son los siguientes:\n"
ls $directorio

